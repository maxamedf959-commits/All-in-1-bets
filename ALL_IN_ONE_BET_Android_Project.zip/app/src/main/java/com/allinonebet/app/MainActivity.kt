package com.allinonebet.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101A32)
private val Blue = Color(0xFF2364E8)
private val Pale = Color(0xFFF3F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AllInOneBetApp() } }
    }
}

@Composable
fun AllInOneBetApp() {
    var page by remember { mutableStateOf("Home") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var signedIn by remember { mutableStateOf(false) }

    if (!signedIn) {
        Column(
            Modifier.fillMaxSize().background(Navy).padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("ALL-IN-ONE BET", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("One dashboard • Multiple services", color = Color.LightGray)
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(value = email, onValueChange = { email = it },
                label = { Text("Email") }, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedLabelColor = Color.White, unfocusedLabelColor = Color.LightGray
                ))
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = password, onValueChange = { password = it },
                label = { Text("Password") }, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedLabelColor = Color.White, unfocusedLabelColor = Color.LightGray
                ))
            Spacer(Modifier.height(20.dp))
            Button(onClick = { signedIn = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Enter demo dashboard")
            }
            Spacer(Modifier.height(12.dp))
            Text("Demo only: this screen does not authenticate users.", color = Color.LightGray, fontSize = 12.sp)
        }
    } else {
        Scaffold(
            containerColor = Pale,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(18.dp)) {
                    Text("ALL-IN-ONE BET", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Dashboard prototype", color = Color.LightGray, fontSize = 12.sp)
                }
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Platforms", "Wallet", "History", "Profile").forEach {
                        NavigationBarItem(selected = page == it, onClick = { page = it },
                            icon = { Text(when(it) {"Home"->"⌂";"Platforms"->"◎";"Wallet"->"◈";"History"->"↻";else->"●"}) },
                            label = { Text(it) })
                    }
                }
            }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Text(when(page) {
                        "Home" -> "Welcome to your dashboard"
                        "Platforms" -> "Betting platforms"
                        "Wallet" -> "Mobcash wallet requests"
                        "History" -> "Recent activity"
                        else -> "Your profile"
                    }, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
                }
                when(page) {
                    "Home" -> {
                        item { InfoCard("Your account", "Demo customer dashboard") }
                        item { InfoCard("Quick access", "Open Platforms to view available service links.") }
                        item { InfoCard("Wallet", "Submit a demo deposit or withdrawal request.") }
                    }
                    "Platforms" -> {
                        item { PlatformCard("1xBet", "External service access is not connected.") }
                        item { PlatformCard("Linebet", "External service access is not connected.") }
                        item { PlatformCard("Winwin", "External service access is not connected.") }
                    }
                    "Wallet" -> {
                        item { InfoCard("Mobcash", "Payment provider integration is not configured.") }
                        item { var amount by remember { mutableStateOf("") }
                            var type by remember { mutableStateOf("Deposit") }
                            var message by remember { mutableStateOf("") }
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Payment request (demo)", fontWeight = FontWeight.Bold)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(type == "Deposit", { type = "Deposit" }); Text("Deposit")
                                        Spacer(Modifier.width(12.dp))
                                        RadioButton(type == "Withdrawal", { type = "Withdrawal" }); Text("Withdrawal")
                                    }
                                    OutlinedTextField(amount, { amount = it }, label = { Text("Amount (USD)") },
                                        modifier = Modifier.fillMaxWidth())
                                    Button(onClick = { message = "Demo $type request recorded locally only." },
                                        modifier = Modifier.fillMaxWidth()) { Text("Submit request") }
                                    if (message.isNotEmpty()) Text(message, color = Blue)
                                }
                            }
                        }
                    }
                    "History" -> item { InfoCard("No transactions", "Demo activity will appear here when recorded.") }
                    else -> {
                        item { InfoCard("Customer profile", "Account: Demo user") }
                        item { InfoCard("Security", "Production login and account approval require a secure backend.") }
                    }
                }
                item {
                    Text("Prototype only — no real bets, deposits, withdrawals, or platform connections.",
                        color = Color(0xFF8A3A26), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(body, color = Color.DarkGray)
        }
    }
}

@Composable
fun PlatformCard(name: String, detail: String) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
                Text(detail, color = Color.DarkGray, fontSize = 13.sp)
            }
            Text("Not connected", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}
