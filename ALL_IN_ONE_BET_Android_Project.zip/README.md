# ALL-IN-ONE BET — Android starter project

This is a native Android Studio starter project for the dashboard prototype.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Current limitations
- Demo-only local screen flow; the sign-in screen does not authenticate.
- No persistent database or secure customer accounts.
- No real administrator approval workflow yet.
- Mobcash payments are not connected; the wallet form is a local demo only.
- 1xBet, Linebet, and Winwin are not connected. Only authorized official links/APIs may be added after access is approved.
- Do not use this prototype to handle real-money transactions.

Package: `com.allinonebet.app`
Minimum Android: 6.0 (API 23)
Target SDK: 35
